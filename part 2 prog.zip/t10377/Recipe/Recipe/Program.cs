﻿// See https://aka.ms/new-console-template for more informationusing System;

namespace RecipeApp
{
    // Main class of the application
    class Program
    {
        // Main method where the program starts execution
        static void Main(string[] args)
        {
            // Instantiate a RecipeManager to manage recipes
            RecipeManager recipeManager = new RecipeManager();

            // Main menu loop
            while (true)
            {
                // Display menu options
                Console.WriteLine("1. Add Recipe");
                Console.WriteLine("2. Display Recipe");
                Console.WriteLine("3. Scale Recipe");
                Console.WriteLine("4. Reset Quantities");
                Console.WriteLine("5. Clear Recipe");
                Console.WriteLine("6. Exit");
                Console.Write("Enter your choice: ");
                int choice = int.Parse(Console.ReadLine());
                Console.WriteLine();

                // Switch to handle user choice
                switch (choice)
                {
                    case 1:
                        recipeManager.AddRecipe();
                        break;
                    case 2:
                        recipeManager.DisplayRecipe();
                        break;
                    case 3:
                        recipeManager.ScaleRecipe();
                        break;
                    case 4:
                        recipeManager.ResetQuantities();
                        break;
                    case 5:
                        recipeManager.ClearRecipe();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

                Console.WriteLine();
            }
        }
    }

    // Class to manage recipes
    class RecipeManager
    {
        // Instance of Recipe class to manage recipe data
        private Recipe recipe;

        // Constructor to initialize a new recipe
        public RecipeManager()
        {
            recipe = new Recipe();
        }

        // Method to add a new recipe
        public void AddRecipe()
        {
            recipe.AddRecipe();
        }

        // Method to display the current recipe
        public void DisplayRecipe()
        {
            recipe.DisplayRecipe();
        }

        // Method to scale the recipe quantities by a factor
        public void ScaleRecipe()
        {
            recipe.ScaleRecipe();
        }

        // Method to reset all quantity values
        public void ResetQuantities()
        {
            recipe.ResetQuantities();
        }

        // Method to clear the entire recipe
        public void ClearRecipe()
        {
            recipe.ClearRecipe();
        }
    }

    // Class representing a recipe
    class Recipe
    {
        // Arrays to store ingredient details and steps
        private string[] ingredients;
        private decimal[] quantities;
        private string[] units;
        private string[] steps;
        private int numIngredients;
        private int numSteps;

        // Constructor to initialize recipe data
        public Recipe()
        {
            ingredients = new string[100];
            quantities = new decimal[100];
            units = new string[100];
            steps = new string[100];
            numIngredients = 0;
            numSteps = 0;
        }

        // Method to add a recipe
        public void AddRecipe()
        {
            Console.Write("Enter the number of ingredients: ");
            numIngredients = int.Parse(Console.ReadLine());

            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write("Enter the name of ingredient #{0}: ", i + 1);
                ingredients[i] = Console.ReadLine();

                Console.Write("Enter the quantity of ingredient #{0}: ", i + 1);
                quantities[i] = decimal.Parse(Console.ReadLine());

                Console.Write("Enter the unit of measurement for ingredient #{0}: ", i + 1);
                units[i] = Console.ReadLine();
            }

            Console.Write("Enter the number of steps: ");
            numSteps = int.Parse(Console.ReadLine());

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write("Enter step #{0}: ", i + 1);
                steps[i] = Console.ReadLine();
            }
        }

        // Method to display the recipe
        public void DisplayRecipe()
        {
            Console.WriteLine("Recipe:");
            Console.WriteLine("Ingredients:");

            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine("{0}. {1} {2}", i + 1, quantities[i], units[i]);
            }

            Console.WriteLine("Steps:");

            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, steps[i]);
            }
        }

        // Method to scale the recipe quantities
        public void ScaleRecipe()
        {
            Console.Write("Enter the scaling factor (0.5, 2, or 3): ");
            decimal factor = decimal.Parse(Console.ReadLine());

            for (int i = 0; i < numIngredients; i++)
            {
                quantities[i] *= factor;
            }
        }

        // Method to reset all quantity values
        public void ResetQuantities()
        {
            // Simply clear the quantity values already entered
            Array.Clear(quantities, 0, quantities.Length);
        }

        // Method to clear the entire recipe
        public void ClearRecipe()
        {
            // Clear all recipe data
            Array.Clear(ingredients, 0, ingredients.Length);
            Array.Clear(quantities, 0, quantities.Length);
            Array.Clear(units, 0, units.Length);
            Array.Clear(steps, 0, steps.Length);
            numIngredients = 0;
            numSteps = 0;
        }
    }
}

